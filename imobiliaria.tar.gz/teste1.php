<?php
session_start();

define( 'DIR_FOTOS', './fotos/'.$_SESSION['dir_tmp'] ); 
$dir = DIR_FOTOS;
 file_put_contents( 'teste.txt', DIR_FOTOS  );

$nome   = $_POST['nome'];

$dados   = 'linha 1';
if ( !is_dir($dir) ) {
   mkdir( $dir, 0777 );
}
$nome_foto = $dir."/{$nome}";
//.. Salva a foto na pasta
file_put_contents( $nome_foto, $dados );