<div class="row fundo_verde_claro">            
   <div class="col-12 altura_linha_1"></div>
</div>

<div class="row  fundo_branco_1">            
   <div class="col-1">
   </div>
   <div class="col-10">
      <img src="./images/logo.png" >
   </div>
   <div class="col-1"> 
   </div>
</div>

<div class="row fundo_verde_claro">            
   <div class="col-12 altura_linha_1"></div>
</div>
