<?php

class Config {
   var $host    = 'localhost';
   var $usuario = 'root';
   var $senha   = 'sucesso';
   var $db      = 'db_imobiliaria';
}