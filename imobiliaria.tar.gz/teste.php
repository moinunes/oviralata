<?php
session_start(); 
$_SESSION['dir_tmp'] = 23;


?>
<!DOCTYPE HTML>
<html lang="pt-br">
<head>
   <title>Imobiliaria</title>

   <meta charset="utf-8" />

   <meta name="keywords" content="imobiliaria,imóvel,imóveis,apartamentos,casas,compra,venda,santos, são vicente,"/>
   <meta name="description" content="Escolha seu imóvel na baixada santista.">   
   <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

   <!--  .css -->
   <link rel="stylesheet" href="./dist/bootstrap-4.1/css/bootstrap.min.css">
   <link href="./dist/jquery-ui/jquery-ui.min.css" rel="stylesheet">     
   <link rel="stylesheet" href="./dist/css/estilo.css" >
   <link rel="stylesheet" href="./dist/css/estilo_slick.css" >
   <link rel="stylesheet" href="./dist/fSelect/fSelect.css" >
   <link rel="stylesheet" type="text/css" href="./dist/slick/slick/slick.css"/>
   <link rel="stylesheet" type="text/css" href="./dist/slick/slick/slick-theme.css"/>  

   <!--  .js -->
   <script src="./dist/js/jquery-3.3.1.min.js"></script>
   <script src="./dist//jquery-ui/jquery-ui.min.js"></script>
   <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
   <script src="./dist/bootstrap-4.1/js/bootstrap.min.js"></script>
   <script src="./dist/fSelect/fSelect.js"></script>
   <script src="./dist/jquery_mask/dist/jquery.mask.min.js"></script>
   <script type="text/javascript" src="./dist/slick/slick/slick.min.js"></script>
   
</head>

    

<body class="fundo_cinza_1">

   
   <!-- anuncios -->
   <form id="frmIndex" class="form-horizontal" action="index.php" method="POST" role="form">      

   <div class="container" id='div_container'>
       
     
      <div class="row">
         <div class="col-12 altura_linha_1"></div>
      </div>

      <!-- nessa linha - vai coluna 1 da esquerda 
                             coluna 2 da direita imprime os anuncios -->         
      <div class="row">         
         
         <!-- d-none d-lg-block - esconde a div em telas menores que LG ( abaixo de 992px ) -->
         <div class="col-lg-3 col-xl-3 d-none d-lg-block">
            <div class="div_esquerda"> <!-- aqui publicidade -->               
            </div>   
         </div>


      <div class="row">         
         <div class="col-12">
            teste ajax
         </div>
      </div>
      
   </div> <!-- /container -->

   
</form>


<script type="text/javascript">

    
$( document ).ready(function() {      

      var url = "teste1.php";
      nome    = 'novo.txt';      
      $.ajax({
        url: url,
        type: "POST",
        async: true,
        data: {          
          nome: nome,          
        },     
        beforeSend: function( xhr ) {
           // alert('antes')
        }
      })
      .done(function(){
         // nada
      });


});


</script>   

</body>

</html>
