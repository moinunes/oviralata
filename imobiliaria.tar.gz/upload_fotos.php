<?php
session_start();

define( 'DIR_FOTOS', './fotos/' );
   
  
$acao = isset($_REQUEST['acao']) ? $_REQUEST['acao'] : '';
switch ($acao) {
   case 'incluir_foto':      
      incluir_foto();
      break;
   
   case 'excluir_foto':
      $fotos->excluir_foto();
      break;

   case 'obter_miniaturas':
      $id_imovel = $_POST['id_imovel'];      
      $fotos->obter_miniaturas($id_imovel);
      break;
   
   default:
      # code...
      break;
}

   /**
   * Inclui a foto na pasta /fotos
   */
   function incluir_foto() {
   
      

      //$fotos->apagar_pastas_tmp();
     print_r($_REQUEST);
      die('fim');

     // $dir = DIR_FOTOS.$_SESSION['dir_tmp'];
     // $imagem = $_REQUEST['imagem'];
     // $tipo   = $_REQUEST['tipo'];
     // $nome   = $_REQUEST['nome'];
     // if ($tipo=='thumbnail'){
     //    $nome = 't_'.$nome;   
     // }
     // $retirar = 'data:image/jpeg;base64,';
     // $imagem  = str_replace( $retirar, '', $imagem );
     // $dados   = base64_decode($imagem);
     // if ( !is_dir($dir) ) {
     //    mkdir( $dir, 0777 );
     // }
     // $nome_foto = $dir."/{$nome}";
     // //.. Salva a foto na pasta
     // file_put_contents( $nome_foto, $dados );
   } // incluir_foto

?>


<!DOCTYPE HTML>
<html lang="pt-br">
<head>
   <title>Imobiliaria</title>

   <meta charset="utf-8">   
   <meta name="keywords" content="imobiliaria,imóvel,imóveis,apartamentos,casas,compra,venda,santos, são vicente,"/>
   <meta name="description" content="Escolha seu imóvel na baixada santista.">   
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <!-- Bootstrap styles -->
   <link rel="stylesheet" href="./dist/bootstrap-4.1/css/bootstrap.min.css">
   <link href="./dist/jquery-ui/jquery-ui.min.css" rel="stylesheet">
     
     <!-- estilo.css -->  
   <link rel="stylesheet" href="./dist/css/estilo.css" >

   <script src="./dist/js/load-image/load-image.all.min.js"></script>
   <script src="./dist/js/jquery-3.3.1.min.js"></script>
   <script src="./dist/bootstrap-4.1/js/bootstrap.js"></script>
   <script src="./dist//jquery-ui/jquery-ui.min.js"></script>

   
</head>

<body class="fundo_branco_1">   

  <form id="frmUpload" class="form-horizontal" action="upload_fotos.php" method="POST" enctype="multipart/form-data" role="form">

     <input type="text" id="acao"   name="acao"   value = "<?=$_REQUEST['acao']?>"/>
     <input type="text" name="frm_nome" id='frm_nome'  />
     <input type="text" name="frm_img"  id='frm_img' />
     

   <div id="div_campos">
   
   </div>


   <div class="row">
      <div class="col-12 border border-sucess rounded fundo_azul_claro">               
         <label for='file-input' class='file_personalizado'>Escolha as Fotos</label>            
         <input id="file-input" type="file"  onchange="upload_fotos()" multiple />
         <div id="div_fotos"></div>   
         <?php
            $dir_tmp = $_SESSION['dir_tmp'];
         ?>
     
      </div>
   </div>   


   <script type="text/javascript">
      
           
       
       //sessionStorage.clear();

      function upload_fotos() {
         var array_dados = [];  
         var files = document.querySelector('input[type=file]').files;

         // thumbnail
         for ( var i = 0, file; file = files[i]; i++) {
            //redimensionar( file, 90, 90 , 'thumbnail' ); 
            largura=90
            altura=90
            var loadingImage = loadImage(
               file,
               function ( img, data ) {
                  //if (tipo=='thumbnail') {
                  //   exibir_miniatura(file.name,img); //.. exibe as miniaturas na tela            
                  //}
                  array_dados[1] = img;

                  $('#frm_nome').val( img.toDataURL("image/jpeg", 0.8 ) );
                  $('#frm_img').val( file.name );

                  //criar_input( img, file, tipo )
               },
               {         
                  maxWidth: largura,
                  maxHeight:altura,
                  orientation:true,        
                  resize:true,
               }
            );
           
            //array_dados[1] = img;
            alert( $('#frm_img').val( ) )
         }
         
         // foto normal
         //for ( var i = 0, file; file = files[i]; i++) {
         //   redimensionar( file, 500,500,  null );
         //}

         console.log( array_dados );
         //salvar_fotos_na_pasta();

      } // upload_fotos



         function redimensionar( file, largura, altura, tipo ) {
         
          var loadingImage = loadImage(
            file,
            function ( img, data ) {
               if (tipo=='thumbnail') {
                  exibir_miniatura(file.name,img); //.. exibe as miniaturas na tela            
               }
               
               $('#frm_nome').val( img.toDataURL("image/jpeg", 0.8 ) );
               $('#frm_img').val( file.name );

               //criar_input( img, file, tipo )
            },
            {         
               maxWidth: largura,
               maxHeight:altura,
               orientation:true,        
               resize:true,
            }
         );
         if (loadingImage) {
         }
      } // redimensionar


      function criar_input( img, file, tipo  ) {

         img_base64  = img.toDataURL("image/jpeg", 0.8 );
         nome_campo  = 'frm_foto_'+tipo+'_'+file.name;
         valor_campo = tipo+'|'+file.name+'|'+img_base64;
         $('#div_campos').append( "<input type='text'" + "id='"+nome_campo+"'"  + "value='"+valor_campo+"'"  +  "/>" );
         
         //_i = 0;
         //_x = ' <input type="text" '+ 'name="frm_fotos['+_i+']" '  + "value='"+valor_campo+"'"  + "/>" ;         
         //_i = 1;
         //_y = ' <input type="text" '+ 'name="frm_fotos['+_i+']" ' +  "value='"+valor_campo+"'"  + "/>" ;
         //$('#div_campos').append( _x );
         //$('#div_campos').append( _y );
         
         //$("#element_id_or_another_selector").eq(0).val("your value");
        
         //$("[id^=frm_fotos]").eq(_i).val(nome_campo);

        
         //$("[id^=frm_fotos]").eq(_i).val(nome_campo);
         // x= JSON.stringify(valor_campo);   

         //$("[id^=frm_fotos]").eq(0).val(valor_campo);
         //$("[id^=frm_fotos]").eq(1).val(valor_campo);
         //array_dados[indice] =  valor_campo;
         //array_dados[ 'teste' ] = valor_campo;
         //array_dados.push(valor_campo);
         //console.log(array_dados)
         //$('#frm_fotos_2').val( 'vixi' );
         //sessionStorage.setItem(  nome_campo, nome_campo );
         
          //alert(indice)
         //$('#frm_fotos_1').val( 'valor_campo' );

       

      }

      

     function salvar_fotos_na_pasta() {     

         //alert("Value 1 is " + sessionStorage.getItem(1));
         //_fotos = document.getElementsByName("frm_fotos");
         
         console.log($('#frm_fotos_1').val())
         //$('#acao').val('incluir_foto');

         //$('#frm_fotos_1').val( sessionStorage.getItem("x") );
         //$('form input').each(function() {
         //       var id = $(this).attr("id"); 
         //       //alert(id)            
         //});
         //for (i = 0; i < array_dados.length; i++) {
         //   text += "<li>" + array_dados[i] + "</li>";
         //}
         //console.log(array_dados.length)
//
//
//var form = jQuery('#frmUpload'),
//    data = form.serialize();
//    console.log(data)
//
         //$("[id^=frm_fotos]").eq(0).val('a1');
         //$("[id^=frm_fotos]").eq(1).val('b2');
         //
         //var x = $("form").serializeArray();
         //$.each(x, function(i, field){
         //     alert(field.name +field.value);
         //});
//         x= JSON.stringify(array_dados);
//         console.log(x)


         //console.log( $('#frm_foto_null_IMG-20180728-WA0060.jpg').val() );
         //$('#imagem').val(img);
         //$('#tipo').val(tipo);
         //$('#nome').val(file.name);
         //$('#frm_array').val( 'array_dados' );

         //$("#frmUpload input").each(function(){         
         //   console.log ( this.value )
         //})
//         document.getElementById("frmUpload").submit();
     }

      function salvar_foto_na_pastaxxxxxxxxxxxxxxxx( img, file, tipo ) {
         var url = "fotos.php";
         nome    = file.name;
         base64  = img.toDataURL("image/jpeg", 0.8 );
         $.ajax({
           url: url,
           type: "POST",
           async: true,
           data: {
             imagem: base64,
             nome: nome,
             tipo: tipo,
             acao: 'incluir_foto',
           },     
           beforeSend: function( xhr ) {
              // alert('antes')
           }
         })
         .done(function(){
            // nada
         });

      } // salvar

      function exibir_miniatura( nome_foto, img ) {
         var nome, id, str;
         nome      = nome_foto;
         id        = 't_'+nome.replace( ".jpg", '' );
         nome_foto = 't_'+nome_foto;
         tem_essa_foto = $('#'+id).length;
         if ( !tem_essa_foto) {
            str  = "<div id='"+id+"' class='btn' >";
            str += '<a href="javascript:excluir_foto(' + "'"+nome_foto+"'"+ ')">Delete</a>';
            str += "</div>";
            $( "#div_fotos" ).append( str );
            $( "#div_fotos" ).find( '#'+id ).prepend( img );
         }   
      } // exibir_miniatura

      function excluir_foto(nome_foto) {
         var url  = "fotos.php";
         var nome = nome_foto;
         id       = nome.replace( ".jpg", '' );
         $.ajax({
           url: url,     
           type: "POST",
           async: true,
           data: {       
             nome_foto: nome_foto,       
             acao: 'excluir_foto',
           }
         })
         .done(function(msg){      
            $('#'+id).remove();
         });
      } //  excluir_foto









         var array_dados = {};

   </script>

</form>

</body>

</html>